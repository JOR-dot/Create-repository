import { formatBRL } from "@shared/menu";

export function useMenuFormat() {
  return { formatBRL };
}
