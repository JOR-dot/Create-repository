import { useMemo, useState } from "react";
import { ChefHat, ChevronDown, CircleAlert, Instagram, MapPin, MessageCircle, RefreshCw, Sparkles } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { trpc } from "@/lib/trpc";
import type { MenuCategory, MenuItem } from "@shared/menu";
import { ACCOMPANIMENTS, formatBRL } from "@shared/menu";
import SiteHeader from "@/components/SiteHeader";
import MenuCard from "@/components/MenuCard";
import ItemDialog from "@/components/ItemDialog";
import CartDrawer from "@/components/CartDrawer";

const tabs: { id: MenuCategory; label: string; eyebrow: string }[] = [
  { id: "dishes", label: "Pratos do Dia", eyebrow: "feito na hora" },
  { id: "drinks", label: "Bebidas", eyebrow: "para refrescar" },
  { id: "accompaniments", label: "Acompanhamentos", eyebrow: "do seu jeito" },
];

export default function Home() {
  const { data: menu, isLoading, isError, refetch } = trpc.menu.list.useQuery();
  const { addItem, totalQuantity, totalCents } = useCart();
  const [activeTab, setActiveTab] = useState<MenuCategory>("dishes");
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const items = menu ?? [];
  const visibleItems = useMemo(() => items.filter(item => item.category === activeTab && item.isVisible), [items, activeTab]);

  return <div className="min-h-screen bg-[#fdfbf7] text-[#302822]">
    <SiteHeader onCart={() => setCartOpen(true)} />
    <main>
      <section className="relative overflow-hidden border-b border-[#eadfce] bg-[#f7eddf]">
        <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full border-[28px] border-[#e8c16c]/35" />
        <div className="pointer-events-none absolute bottom-[-80px] left-[-30px] h-52 w-52 rounded-full bg-[#c82333]/8" />
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 pb-12 pt-12 sm:px-6 sm:pb-16 sm:pt-16 lg:grid-cols-[1.15fr_0.85fr] lg:px-8 lg:py-20">
          <div className="relative">
            <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#d9b37e] bg-[#fffaf1] px-3 py-1.5 text-[0.64rem] font-black uppercase tracking-[0.18em] text-[#a2644c]"><Sparkles className="h-3.5 w-3.5 text-[#c82333]" /> sábado na esquina</span>
            <h1 className="max-w-2xl font-display text-[clamp(3rem,8vw,6.8rem)] font-bold leading-[0.88] tracking-[-0.055em] text-[#302822]">Almoço com<br /><span className="text-[#c82333]">gosto de casa.</span></h1>
            <p className="mt-6 max-w-lg text-base leading-relaxed text-[#715f50] sm:text-lg">Escolha seu prato, monte do seu jeito e peça pelo WhatsApp. A gente prepara tudo quentinho, como deve ser.</p>
            <div className="mt-8 flex flex-wrap items-center gap-3"><button onClick={() => document.getElementById("cardapio")?.scrollIntoView({ behavior: "smooth" })} className="rounded-full bg-[#c82333] px-5 py-3 text-sm font-black text-white shadow-[4px_4px_0_#8f1b28] transition hover:-translate-y-0.5 hover:bg-[#a91d2b]">Ver cardápio <ChevronDown className="ml-1 inline h-4 w-4" /></button><span className="flex items-center gap-2 text-xs font-bold text-[#846e5d]"><MapPin className="h-4 w-4 text-[#c82333]" /> Rua da esquina, sempre perto</span></div>
          </div>
          <div className="relative mx-auto w-full max-w-sm lg:justify-self-end">
            <div className="rotate-2 rounded-[2rem] border-[10px] border-[#c82333] bg-[#fffaf1] p-5 shadow-[12px_14px_0_#e6c166] sm:p-7"><div className="border border-dashed border-[#dcbf9b] p-5 text-center sm:p-7"><p className="font-display text-4xl font-bold leading-none text-[#c82333]">Esquina<br /><span className="text-[#302822]">Barcelos</span></p><div className="mx-auto my-5 h-px w-20 bg-[#d8ae3d]" /><p className="text-[0.65rem] font-black uppercase tracking-[0.2em] text-[#866f5e]">prato feito • conversa boa</p><p className="mt-6 font-display text-2xl font-bold text-[#a2644c]">desde a esquina</p></div></div>
            <div className="absolute -bottom-7 -left-3 rotate-[-8deg] rounded-full bg-[#e6c166] px-4 py-3 text-center text-[0.62rem] font-black uppercase leading-tight tracking-[0.12em] text-[#59411b] shadow-lg">feito<br />com afeto</div>
          </div>
        </div>
      </section>

      <section id="cardapio" className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
        <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-[0.66rem] font-black uppercase tracking-[0.2em] text-[#a2644c]">o cardápio de hoje</p><h2 className="mt-2 font-display text-4xl font-bold leading-none text-[#302822] sm:text-5xl">Escolha sem pressa.</h2></div><div className="flex items-center gap-2 rounded-full bg-[#f7eddf] px-3 py-2 text-xs font-bold text-[#846e5d]"><ChefHat className="h-4 w-4 text-[#c82333]" /> sábado, do jeitinho da casa</div></div>
        <div className="mb-8 flex gap-2 overflow-x-auto pb-2">
          {tabs.map(tab => <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`min-w-max rounded-full border px-4 py-2.5 text-left transition ${activeTab === tab.id ? "border-[#c82333] bg-[#c82333] text-white shadow-[3px_3px_0_#e6c166]" : "border-[#eadfce] bg-white text-[#6e5a4c] hover:border-[#d5b5a0]"}`}><span className="block text-sm font-extrabold">{tab.label}</span><span className={`mt-0.5 block text-[0.58rem] font-bold uppercase tracking-[0.13em] ${activeTab === tab.id ? "text-white/70" : "text-[#a18a77]"}`}>{tab.eyebrow}</span></button>)}
        </div>
        {activeTab === "accompaniments" ? <div className="grid gap-5 lg:grid-cols-[1fr_0.8fr]"><div className="rounded-[1.5rem] border border-[#eadfce] bg-[#fffaf1] p-6 sm:p-8"><div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#edf3e5] text-[#69834f]"><ChefHat className="h-6 w-6" /></div><h3 className="font-display text-3xl font-bold text-[#302822]">Do seu jeito</h3><p className="mt-3 max-w-md text-sm leading-relaxed text-[#7e6f62]">Os acompanhamentos deixam o prato ainda mais com cara de almoço de família. Marque suas preferências quando escolher um prato.</p><div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">{ACCOMPANIMENTS.map(item => <div key={item} className="rounded-xl border border-[#dce7d1] bg-[#f4f7ef] px-3 py-4 text-center text-sm font-extrabold text-[#5e7549]">{item}</div>)}</div></div><div className="rounded-[1.5rem] bg-[#2e2823] p-6 text-[#fffaf1] sm:p-8"><p className="text-[0.65rem] font-black uppercase tracking-[0.16em] text-[#e6c166]">um aviso da casa</p><p className="mt-4 font-display text-3xl font-bold leading-tight">Qualquer acompanhamento que não pertença ao prato será cobrado à parte.</p><p className="mt-5 text-sm leading-relaxed text-white/65">Caso não queira algum, avise o atendente. A ideia é o seu prato ficar exatamente como você gosta.</p></div></div> : isLoading ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{[1,2,3].map(id => <div key={id} className="h-48 animate-pulse rounded-[1.35rem] bg-[#f3e9da]" />)}</div> : isError ? <div className="rounded-2xl border border-[#f0c7bf] bg-[#fff2ef] p-6 text-[#9b3d31]"><div className="flex items-center gap-2 font-bold"><CircleAlert className="h-5 w-5" /> Não conseguimos carregar o cardápio.</div><button onClick={() => refetch()} className="mt-4 flex items-center gap-2 text-sm font-black underline"><RefreshCw className="h-4 w-4" /> tentar novamente</button></div> : visibleItems.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{visibleItems.map(item => <MenuCard key={item.id} item={item} onSelect={setSelectedItem} />)}</div> : <div className="rounded-2xl border border-[#eadfce] bg-white p-8 text-center text-[#7e6f62]">Nenhum item disponível nesta categoria agora.</div>}
      </section>

      <section className="border-y border-[#eadfce] bg-[#f7eddf]"><div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8"><div><p className="font-display text-2xl font-bold text-[#302822]">Ficou com fome?</p><p className="mt-1 text-sm text-[#846e5d]">Seu pedido é montado em poucos cliques.</p></div><button onClick={() => setCartOpen(true)} className="flex items-center justify-center gap-2 rounded-full bg-[#2e2823] px-5 py-3 text-sm font-black text-white transition hover:bg-[#c82333]"><MessageCircle className="h-4 w-4" /> {totalQuantity ? `${totalQuantity} ${totalQuantity === 1 ? "item" : "itens"} · ${formatBRL(totalCents)}` : "Abrir meu pedido"}</button></div></section>
    </main>
    <footer className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-xs text-[#9a8170] sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8"><p>Esquina Barcelos · comida de sábado com gosto de casa.</p><div className="flex items-center gap-4"><span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> peça pelo WhatsApp</span><Instagram className="h-4 w-4" /></div></footer>
    <ItemDialog item={selectedItem} open={Boolean(selectedItem)} onOpenChange={open => !open && setSelectedItem(null)} onAdd={selection => { if (selectedItem) addItem({ item: selectedItem, ...selection }); }} />
    <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    {totalQuantity > 0 && !cartOpen && <button onClick={() => setCartOpen(true)} className="fixed bottom-5 right-4 z-20 flex items-center gap-3 rounded-full bg-[#c82333] px-5 py-3 text-sm font-black text-white shadow-[4px_4px_0_#8f1b28] transition hover:-translate-y-1 sm:hidden"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#f4c647] text-[0.7rem] text-[#4d3211]">{totalQuantity}</span> ver pedido <span className="text-white/70">{formatBRL(totalCents)}</span></button>}
  </div>;
}
