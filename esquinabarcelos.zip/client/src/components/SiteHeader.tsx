import { ArrowUpRight, CircleUserRound, ShoppingBag } from "lucide-react";
import { Link } from "wouter";
import { useCart } from "@/context/CartContext";

export default function SiteHeader({ onCart }: { onCart: () => void }) {
  const { totalQuantity } = useCart();
  return (
    <header className="sticky top-0 z-30 border-b border-[#eadfce] bg-[#fdfbf7]/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="group flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-[#c82333] text-[#fff8e9] shadow-[3px_3px_0_#e4a82e] transition-transform group-hover:-rotate-3">
            <span className="font-display text-xl font-bold">EB</span>
          </span>
          <span>
            <span className="block font-display text-[1.25rem] font-bold leading-none text-[#2b2621]">Esquina Barcelos</span>
            <span className="mt-1 block text-[0.58rem] font-extrabold uppercase tracking-[0.22em] text-[#a2644c]">comida de sábado</span>
          </span>
        </Link>
        <div className="flex items-center gap-2">
          <Link href="/admin" className="hidden items-center gap-1 rounded-full px-3 py-2 text-xs font-bold text-[#6e5a4c] transition hover:bg-[#f3e9da] sm:flex">
            Área do dono <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
          <button onClick={onCart} className="relative flex h-10 items-center gap-2 rounded-full bg-[#c82333] px-3.5 text-sm font-extrabold text-white shadow-[3px_3px_0_#8f1b28] transition hover:-translate-y-0.5 active:translate-y-0">
            <ShoppingBag className="h-4 w-4" />
            <span className="hidden sm:inline">Meu pedido</span>
            {totalQuantity > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#f4c647] px-1 text-[0.68rem] font-black text-[#4d3211]">{totalQuantity}</span>}
          </button>
        </div>
      </div>
    </header>
  );
}
