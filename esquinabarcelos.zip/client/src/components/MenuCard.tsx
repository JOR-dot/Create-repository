import { Check, ChevronRight, Clock3, Plus } from "lucide-react";
import type { MenuItem } from "@shared/menu";
import { formatBRL } from "@shared/menu";

const accents = {
  dishes: { tag: "prato do dia", color: "#c82333", pale: "#fbe9e7" },
  drinks: { tag: "bebida", color: "#ad6b25", pale: "#fff1cf" },
  accompaniments: { tag: "acompanhamento", color: "#69834f", pale: "#edf3e5" },
};

export default function MenuCard({ item, onSelect }: { item: MenuItem; onSelect: (item: MenuItem) => void }) {
  const accent = accents[item.category];
  const minPrice = item.variants[0]?.priceCents ?? 0;
  const unavailable = !item.isAvailable;
  return (
    <article className={`group relative flex min-h-[188px] flex-col justify-between overflow-hidden rounded-[1.35rem] border border-[#ebdfcf] bg-white p-5 shadow-[0_10px_28px_rgba(93,62,35,0.06)] transition hover:-translate-y-1 hover:shadow-[0_15px_36px_rgba(93,62,35,0.12)] ${unavailable ? "opacity-70" : ""}`}>
      <div className="absolute right-0 top-0 h-16 w-16 rounded-bl-[2rem]" style={{ backgroundColor: accent.pale }} />
      <div className="relative">
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="rounded-full px-2.5 py-1 text-[0.62rem] font-black uppercase tracking-[0.16em]" style={{ backgroundColor: accent.pale, color: accent.color }}>{accent.tag}</span>
          {unavailable ? <span className="flex items-center gap-1 text-[0.66rem] font-bold text-[#9a8170]"><Clock3 className="h-3.5 w-3.5" /> esgotado</span> : <Check className="h-4 w-4 text-[#719252]" />}
        </div>
        <h3 className="max-w-[18rem] font-display text-[1.4rem] font-bold leading-[1.02] text-[#302822]">{item.name}</h3>
        <p className="mt-2 max-w-[22rem] text-sm leading-relaxed text-[#7e6f62]">{item.description}</p>
      </div>
      <div className="relative mt-5 flex items-end justify-between gap-4">
        <div>
          <span className="block text-[0.64rem] font-bold uppercase tracking-[0.16em] text-[#a18a77]">a partir de</span>
          <span className="font-display text-[1.35rem] font-bold text-[#c82333]">{formatBRL(minPrice)}</span>
        </div>
        <button disabled={unavailable} onClick={() => onSelect(item)} className="flex h-10 items-center gap-2 rounded-full bg-[#2e2823] px-4 text-xs font-black text-[#fffaf1] transition group-hover:bg-[#c82333] disabled:cursor-not-allowed disabled:bg-[#b8aa9c]">
          <Plus className="h-4 w-4" /> adicionar <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </article>
  );
}
