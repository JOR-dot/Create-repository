import { useEffect, useState } from "react";
import { Minus, Plus, Utensils } from "lucide-react";
import type { Accompaniment, MenuItem } from "@shared/menu";
import { ACCOMPANIMENTS, formatBRL } from "@shared/menu";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function ItemDialog({ item, open, onOpenChange, onAdd }: { item: MenuItem | null; open: boolean; onOpenChange: (open: boolean) => void; onAdd: (selection: { variantLabel: string; unitPriceCents: number; accompaniments: Accompaniment[] }) => void }) {
  const [variantIndex, setVariantIndex] = useState(0);
  const [accompaniments, setAccompaniments] = useState<Accompaniment[]>([]);

  useEffect(() => {
    if (open) {
      setVariantIndex(0);
      setAccompaniments([]);
    }
  }, [open, item?.id]);

  if (!item) return null;
  const variant = item.variants[variantIndex];
  const toggleAccompaniment = (value: Accompaniment) => setAccompaniments(current => current.includes(value) ? current.filter(item => item !== value) : [...current, value]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-[1.5rem] border-[#eadfce] bg-[#fffdf9] p-0 shadow-2xl sm:max-w-lg">
        <div className="bg-[#c82333] px-6 pb-7 pt-8 text-[#fffaf1]">
          <span className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-[0.62rem] font-black uppercase tracking-[0.16em]"><Utensils className="h-3.5 w-3.5" /> montando seu pedido</span>
          <DialogHeader>
            <DialogTitle className="font-display text-3xl font-bold text-white">{item.name}</DialogTitle>
            <DialogDescription className="mt-2 text-sm leading-relaxed text-white/75">{item.description}</DialogDescription>
          </DialogHeader>
        </div>
        <div className="space-y-7 px-6 py-6">
          <section>
            <div className="mb-3 flex items-end justify-between"><div><p className="text-[0.65rem] font-black uppercase tracking-[0.16em] text-[#a2644c]">1. escolha o tamanho</p><p className="mt-1 text-sm text-[#7e6f62]">Selecione a porção ideal para hoje.</p></div><span className="font-display text-xl font-bold text-[#c82333]">{formatBRL(variant?.priceCents ?? 0)}</span></div>
            <div className="grid gap-2 sm:grid-cols-3">
              {item.variants.map((option, index) => <button key={option.label} onClick={() => setVariantIndex(index)} className={`rounded-xl border px-3 py-3 text-left transition ${variantIndex === index ? "border-[#c82333] bg-[#fbe9e7] text-[#c82333] shadow-[2px_2px_0_#f0b4ae]" : "border-[#eadfce] bg-white text-[#59483c] hover:border-[#d4ad9a]"}`}><span className="block text-sm font-extrabold">{option.label === "PF" ? "Prato Feito" : option.label}</span><span className="mt-1 block text-xs font-semibold opacity-75">{formatBRL(option.priceCents)}</span></button>)}
            </div>
          </section>
          {item.category === "dishes" && <section>
            <div className="mb-3"><p className="text-[0.65rem] font-black uppercase tracking-[0.16em] text-[#a2644c]">2. do seu jeito</p><p className="mt-1 text-sm text-[#7e6f62]">Acompanhamentos fora do prato são cobrados à parte.</p></div>
            <div className="grid grid-cols-2 gap-2">
              {ACCOMPANIMENTS.map(option => <label key={option} className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-3 text-sm font-bold transition ${accompaniments.includes(option) ? "border-[#d8ae3d] bg-[#fff6dd] text-[#785516]" : "border-[#eadfce] bg-white text-[#59483c]"}`}><input type="checkbox" checked={accompaniments.includes(option)} onChange={() => toggleAccompaniment(option)} className="h-4 w-4 accent-[#c82333]" />{option}</label>)}
            </div>
          </section>}
        </div>
        <DialogFooter className="border-t border-[#eadfce] bg-[#fffaf1] px-6 py-4 sm:flex-row sm:justify-between">
          <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="text-[#7e6f62]">Cancelar</Button>
          <Button type="button" onClick={() => { if (!variant) return; onAdd({ variantLabel: variant.label, unitPriceCents: variant.priceCents, accompaniments }); onOpenChange(false); }} className="h-11 rounded-full bg-[#c82333] px-6 font-black text-white shadow-[3px_3px_0_#8f1b28] hover:bg-[#a91d2b]">Adicionar ao pedido <Plus className="h-4 w-4" /></Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
