import { useState } from "react";
import { ArrowRight, Check, MapPin, Minus, Pencil, Plus, ShoppingBag, Trash2, X } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatBRL } from "@shared/menu";
import { Button } from "@/components/ui/button";

type DeliveryMode = "delivery" | "pickup";

export default function CartDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { items, totalCents, updateQuantity, removeItem, clear } = useCart();
  const [mode, setMode] = useState<DeliveryMode>("pickup");
  const [customerName, setCustomerName] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState("");

  const finishOrder = () => {
    if (!items.length) return setError("Adicione pelo menos um item ao pedido.");
    if (!customerName.trim()) return setError("Digite seu nome para continuar.");
    if (mode === "delivery" && !address.trim()) return setError("Informe o endereço de entrega.");
    const lines = [
      "Olá, Esquina Barcelos! Quero fazer um pedido:",
      "",
      `Cliente: ${customerName.trim()}`,
      `Modalidade: ${mode === "delivery" ? "Entrega" : "Retirada no local"}`,
      ...(mode === "delivery" ? [`Endereço: ${address.trim()}`] : []),
      "",
      "Itens:",
      ...items.map(item => `• ${item.quantity}x ${item.name} — ${item.variantLabel}${item.accompaniments.length ? ` | acompanhamentos: ${item.accompaniments.join(", ")}` : ""} — ${formatBRL(item.unitPriceCents * item.quantity)}`),
      "",
      `Total: ${formatBRL(totalCents)}`,
      "Acompanhamentos extras, quando aplicável, serão confirmados à parte pelo atendente.",
    ];
    const url = `https://wa.me/5521987725876?text=${encodeURIComponent(lines.join("\n"))}`;
    window.open(url, "_blank", "noopener,noreferrer");
    setError("");
  };

  return <div className={`fixed inset-0 z-50 transition ${open ? "pointer-events-auto" : "pointer-events-none"}`} aria-hidden={!open}>
    <div onClick={onClose} className={`absolute inset-0 bg-[#2f2019]/45 transition-opacity ${open ? "opacity-100" : "opacity-0"}`} />
    <aside className={`absolute bottom-0 right-0 top-0 flex w-full max-w-xl flex-col bg-[#fffdf9] shadow-2xl transition-transform duration-300 sm:top-3 sm:bottom-3 sm:right-3 sm:rounded-[1.5rem] ${open ? "translate-x-0" : "translate-x-full"}`}>
      <div className="flex items-center justify-between border-b border-[#eadfce] px-5 py-5 sm:px-7">
        <div><p className="text-[0.64rem] font-black uppercase tracking-[0.18em] text-[#a2644c]">quase na mesa</p><h2 className="font-display text-2xl font-bold text-[#302822]">Meu pedido</h2></div>
        <button onClick={onClose} className="grid h-10 w-10 place-items-center rounded-full bg-[#f3e9da] text-[#6e5a4c] transition hover:bg-[#eadfce]"><X className="h-5 w-5" /></button>
      </div>
      {items.length === 0 ? <div className="flex flex-1 flex-col items-center justify-center px-8 text-center"><span className="grid h-16 w-16 place-items-center rounded-full bg-[#fbe9e7] text-[#c82333]"><ShoppingBag className="h-7 w-7" /></span><h3 className="mt-5 font-display text-2xl font-bold text-[#302822]">Seu pedido está vazio</h3><p className="mt-2 max-w-xs text-sm leading-relaxed text-[#7e6f62]">Escolha um prato, bebida ou acompanhamento para começar.</p><Button onClick={onClose} className="mt-6 rounded-full bg-[#c82333] font-black text-white hover:bg-[#a91d2b]">Ver cardápio <ArrowRight className="h-4 w-4" /></Button></div> : <>
        <div className="flex-1 space-y-3 overflow-y-auto px-5 py-5 sm:px-7">
          {items.map(item => <div key={item.id} className="rounded-2xl border border-[#eadfce] bg-white p-4"><div className="flex justify-between gap-3"><div><h3 className="text-sm font-extrabold text-[#302822]">{item.name}</h3><p className="mt-1 text-xs font-semibold text-[#957f6e]">{item.variantLabel}{item.accompaniments.length ? ` · ${item.accompaniments.join(", ")}` : ""}</p></div><span className="font-display text-lg font-bold text-[#c82333]">{formatBRL(item.unitPriceCents * item.quantity)}</span></div><div className="mt-3 flex items-center justify-between"><button onClick={() => removeItem(item.id)} className="flex items-center gap-1 text-xs font-bold text-[#aa6b5d] hover:text-[#c82333]"><Trash2 className="h-3.5 w-3.5" /> remover</button><div className="flex items-center gap-2 rounded-full bg-[#f7f0e7] p-1"><button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="grid h-7 w-7 place-items-center rounded-full bg-white text-[#6e5a4c] shadow-sm"><Minus className="h-3.5 w-3.5" /></button><span className="min-w-5 text-center text-sm font-black text-[#302822]">{item.quantity}</span><button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="grid h-7 w-7 place-items-center rounded-full bg-[#c82333] text-white shadow-sm"><Plus className="h-3.5 w-3.5" /></button></div></div></div>)}
          <div className="rounded-2xl bg-[#fff5d8] p-4 text-xs leading-relaxed text-[#765b2b]"><strong>Importante:</strong> qualquer acompanhamento que não pertença ao prato será cobrado à parte e confirmado pelo atendente no WhatsApp. Caso não queira algum, avise o atendente.</div>
          <div className="space-y-4 border-t border-[#eadfce] pt-5"><div><label className="mb-2 block text-xs font-black uppercase tracking-[0.14em] text-[#866f5e]">Seu nome</label><input value={customerName} onChange={event => setCustomerName(event.target.value)} placeholder="Como podemos te chamar?" className="h-11 w-full rounded-xl border border-[#eadfce] bg-white px-3 text-sm text-[#302822] outline-none transition focus:border-[#c82333] focus:ring-2 focus:ring-[#c82333]/15" /></div><div><label className="mb-2 block text-xs font-black uppercase tracking-[0.14em] text-[#866f5e]">Como você prefere?</label><div className="grid grid-cols-2 gap-2"><button onClick={() => setMode("pickup")} className={`flex items-center justify-center gap-2 rounded-xl border py-3 text-sm font-extrabold ${mode === "pickup" ? "border-[#c82333] bg-[#fbe9e7] text-[#c82333]" : "border-[#eadfce] bg-white text-[#6e5a4c]"}`}><Check className={`h-4 w-4 ${mode === "pickup" ? "opacity-100" : "opacity-0"}`} /> retirada</button><button onClick={() => setMode("delivery")} className={`flex items-center justify-center gap-2 rounded-xl border py-3 text-sm font-extrabold ${mode === "delivery" ? "border-[#c82333] bg-[#fbe9e7] text-[#c82333]" : "border-[#eadfce] bg-white text-[#6e5a4c]"}`}><MapPin className={`h-4 w-4 ${mode === "delivery" ? "opacity-100" : "opacity-0"}`} /> entrega</button></div></div>{mode === "delivery" && <div><label className="mb-2 block text-xs font-black uppercase tracking-[0.14em] text-[#866f5e]">Endereço de entrega</label><textarea value={address} onChange={event => setAddress(event.target.value)} placeholder="Rua, número, complemento e bairro" rows={3} className="w-full resize-none rounded-xl border border-[#eadfce] bg-white px-3 py-3 text-sm text-[#302822] outline-none transition focus:border-[#c82333] focus:ring-2 focus:ring-[#c82333]/15" /></div>}</div>
        </div>
        <div className="border-t border-[#eadfce] bg-[#fffaf1] px-5 py-5 sm:px-7"><div className="mb-4 flex items-center justify-between"><span className="text-sm font-bold text-[#7e6f62]">Total dos itens</span><span className="font-display text-2xl font-bold text-[#c82333]">{formatBRL(totalCents)}</span></div>{error && <p className="mb-3 text-xs font-bold text-[#c82333]">{error}</p>}<Button onClick={finishOrder} className="h-12 w-full rounded-full bg-[#c82333] text-sm font-black text-white shadow-[3px_3px_0_#8f1b28] hover:bg-[#a91d2b]">Finalizar pelo WhatsApp <ArrowRight className="h-4 w-4" /></Button><button onClick={clear} className="mx-auto mt-3 flex items-center gap-1 text-xs font-bold text-[#9a8170] hover:text-[#c82333]"><Pencil className="h-3.5 w-3.5" /> limpar pedido</button></div>
      </>}
    </aside>
  </div>;
}
