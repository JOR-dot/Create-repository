import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { Accompaniment, MenuItem } from "@shared/menu";

export type CartItem = {
  id: string;
  itemId: string;
  name: string;
  variantLabel: string;
  unitPriceCents: number;
  accompaniments: Accompaniment[];
  quantity: number;
};

type AddSelection = {
  item: MenuItem;
  variantLabel: string;
  unitPriceCents: number;
  accompaniments?: Accompaniment[];
};

type CartContextValue = {
  items: CartItem[];
  totalCents: number;
  totalQuantity: number;
  addItem: (selection: AddSelection) => void;
  updateQuantity: (id: string, quantity: number) => void;
  removeItem: (id: string) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const value = useMemo<CartContextValue>(() => {
    const addItem = (selection: AddSelection) => {
      setItems(current => {
        const accompaniments = selection.accompaniments ?? [];
        const existing = current.find(item =>
          item.itemId === selection.item.id &&
          item.variantLabel === selection.variantLabel &&
          item.accompaniments.join("|") === accompaniments.join("|"),
        );
        if (existing) {
          return current.map(item => item.id === existing.id ? { ...item, quantity: item.quantity + 1 } : item);
        }
        return [...current, {
          id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
          itemId: selection.item.id,
          name: selection.item.name,
          variantLabel: selection.variantLabel,
          unitPriceCents: selection.unitPriceCents,
          accompaniments,
          quantity: 1,
        }];
      });
    };

    const updateQuantity = (id: string, quantity: number) => {
      setItems(current => quantity <= 0 ? current.filter(item => item.id !== id) : current.map(item => item.id === id ? { ...item, quantity } : item));
    };

    const removeItem = (id: string) => setItems(current => current.filter(item => item.id !== id));
    const clear = () => setItems([]);
    const totalCents = items.reduce((sum, item) => sum + item.unitPriceCents * item.quantity, 0);
    const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
    return { items, totalCents, totalQuantity, addItem, updateQuantity, removeItem, clear };
  }, [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error("useCart must be used within CartProvider");
  return value;
}
