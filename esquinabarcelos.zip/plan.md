# Plano — Esquina Barcelos

## Escopo aprovado

Aplicação web mobile-first para o cardápio digital de sábado da Esquina Barcelos, com seleção de tamanhos e acompanhamentos, carrinho, dados de entrega/retirada e fechamento por WhatsApp. A mesma aplicação terá uma área `/admin` protegida para o proprietário manter itens, preços, visibilidade e disponibilidade.

## Abordagem de implementação

- **Frontend:** React + TypeScript + Tailwind CSS, rotas com Wouter e ícones Lucide. O estado do pedido será mantido em um `CartContext`, com itens imutáveis e cálculo de total em centavos para evitar erros de ponto flutuante.
- **Backend:** Express + tRPC do starter Webdev, com procedimentos públicos para leitura do cardápio e procedimentos administrativos protegidos por `adminProcedure`.
- **Persistência:** banco MySQL gerenciado do projeto via Drizzle. O cardápio será modelado em uma tabela tipada com variantes de tamanho serializadas em JSON; um seed idempotente insere os dados iniciais apenas quando a tabela está vazia. A interface mantém fallback local para o primeiro carregamento quando o banco ainda estiver indisponível.
- **Autenticação:** preservar o fluxo oficial de sessão do starter/Manus OAuth, usando a role `admin` derivada do proprietário. O cookie de sessão segue `SameSite=None; Secure` para funcionar no Preview incorporado. A tela `/admin` redireciona para login quando necessário e trata estados de carregamento, acesso negado e encerramento de sessão.
- **WhatsApp:** montar uma mensagem legível com cliente, modalidade, endereço, itens, quantidades, tamanhos, acompanhamentos e total; abrir `https://wa.me/5521987725876?text=...` em nova navegação.
- **Confiabilidade:** validação no frontend para dados do pedido e no backend para payloads de CRUD; valores em centavos; mensagens de erro com retry/toast; manifesto de rotas estático em `/manus-routes.json`.

## Direção visual

### Alternativas consideradas

- **Tradição editorial portuguesa** — 0,06: papel creme, serifas e detalhes de azulejo.
- **Bistrô urbano minimalista** — 0,04: branco, preto e vermelho com ritmo editorial.
- **Mercado de bairro artesanal** — 0,08: vermelho artesanal, mostarda e terracota em uma interface tátil.

### Escolha: Mercado de bairro artesanal

- **Movimento:** identidade de mercado tradicional luso-brasileiro reinterpretada em UI editorial contemporânea.
- **Princípios:** calor humano, leitura rápida em pé, contraste alto para ações, e detalhes artesanais sem excesso decorativo.
- **Filosofia de cor:** o vermelho `#C82333` comunica apetite e assinatura da casa; mostarda e terracota aquecem a experiência; o creme `#FDFBF7` remete ao papel de cardápio e reduz a fadiga visual.
- **Paradigma de layout:** cabeçalho compacto e manifesto de oferta no topo; conteúdo em uma coluna principal com cartões assimétricos e carrinho como painel fixo de decisão, evitando uma grade genérica centralizada.
- **Elementos assinatura:** selo circular “Sábado na Esquina”, filete vermelho irregular nos títulos e pílulas de preço em mostarda.
- **Interação:** cada ação deve responder imediatamente; adicionar um item abre a escolha contextual, e o carrinho sempre fica acessível sem esconder o cardápio.
- **Animação:** entradas curtas de 160–220ms, deslocamento vertical sutil para cards e transição lateral do carrinho; sem animações que atrasem a escolha em conexão móvel.
- **Tipografia:** `Fraunces` para marca, títulos e preços expressivos; `Manrope` para interface, descrições e formulários.
- **Essência:** “comida de sábado com gosto de esquina, agora pronta para pedir pelo celular”; acolhedora, direta, artesanal.
- **Voz:** títulos curtos e convidativos. Exemplos: “Escolha o tamanho, a gente prepara o resto.” e “Seu almoço merece chegar quentinho.”
- **Wordmark/logo:** nome em serif display com um pequeno losango vermelho entre “Esquina” e “Barcelos”, acompanhado do selo “desde a esquina”.
- **Cor proprietária:** vermelho artesanal `#C82333`.

## Estrutura do projeto

- `client/src/pages/Home.tsx`: cardápio público, abas, seleção, carrinho e checkout.
- `client/src/pages/Admin.tsx`: login/estado administrativo, tabela de itens e editor de CRUD.
- `client/src/components/`: cabeçalho, cards, modal de item, carrinho, admin editor e componentes reutilizáveis.
- `client/src/context/CartContext.tsx`: estado e operações do pedido.
- `client/src/hooks/`: hooks de domínio quando necessário.
- `shared/menu.ts`: tipos compartilhados, opções de acompanhamento, formatação e dados iniciais do cardápio.
- `server/routers.ts`: API tRPC de cardápio e administração.
- `server/db.ts`: consultas, seed idempotente e persistência.
- `drizzle/schema.ts` e `drizzle/`: modelo e migrações.
- `public/manus-routes.json`: declaração das rotas públicas e administrativas.

## Frontend/backend serving

O Preview e a publicação usarão o servidor Express na porta 3000, com `pnpm dev` em desenvolvimento e `pnpm build`/`pnpm start` em produção. A saúde permanece em `/api/health`; o frontend e a API tRPC ficam no mesmo origin para preservar cookies e chamadas autenticadas.
