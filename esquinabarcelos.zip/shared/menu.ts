export type MenuCategory = "dishes" | "drinks" | "accompaniments";

export type MenuVariant = {
  label: string;
  priceCents: number;
};

export type MenuItem = {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: MenuCategory;
  variants: MenuVariant[];
  isAvailable: boolean;
  isVisible: boolean;
  sortOrder: number;
};

export type MenuItemInput = Omit<MenuItem, "id" | "slug"> & {
  id?: string;
  slug?: string;
};

export const ACCOMPANIMENTS = ["Arroz", "Feijão", "Farofa", "Salada"] as const;
export type Accompaniment = (typeof ACCOMPANIMENTS)[number];

export const DEFAULT_MENU_ITEMS: MenuItem[] = [
  {
    id: "fitness",
    slug: "fitness",
    name: "Fitness",
    description: "Arroz, legumes e frango grelhado",
    category: "dishes",
    variants: [{ label: "PF", priceCents: 2800 }],
    isAvailable: true,
    isVisible: true,
    sortOrder: 1,
  },
  {
    id: "calabresa-ovo",
    slug: "calabresa-ovo",
    name: "Calabresa c/ ovo",
    description: "Calabresa dourada, ovo e acompanhamentos da casa",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2100 },
      { label: "PF", priceCents: 2600 },
      { label: "Refeição", priceCents: 3700 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 2,
  },
  {
    id: "frango-empanado",
    slug: "frango-empanado",
    name: "Filé de Frango empanado c/ fritas",
    description: "Crocante por fora, suculento por dentro, com fritas",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2300 },
      { label: "PF", priceCents: 2800 },
      { label: "Refeição", priceCents: 3900 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 3,
  },
  {
    id: "estrogonofe-frango",
    slug: "estrogonofe-frango",
    name: "Estrogonofe de frango c/ batata palha",
    description: "Molho cremoso, frango e batata palha crocante",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2500 },
      { label: "PF", priceCents: 3000 },
      { label: "Refeição", priceCents: 4100 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 4,
  },
  {
    id: "file-peixe",
    slug: "file-peixe",
    name: "Filé de Peixe c/ legumes",
    description: "Peixe grelhado e legumes temperados",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2700 },
      { label: "PF", priceCents: 3200 },
      { label: "Refeição", priceCents: 4400 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 5,
  },
  {
    id: "carne-assada",
    slug: "carne-assada",
    name: "Carne Assada c/ batatas coradas",
    description: "Carne assada macia e batatas douradas",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2700 },
      { label: "PF", priceCents: 3200 },
      { label: "Refeição", priceCents: 4400 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 6,
  },
  {
    id: "picanha-suina",
    slug: "picanha-suina",
    name: "Picanha suína c/ batatas coradas",
    description: "Picanha suína dourada com batatas da casa",
    category: "dishes",
    variants: [
      { label: "Mini", priceCents: 2700 },
      { label: "PF", priceCents: 3200 },
      { label: "Refeição", priceCents: 4400 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 7,
  },
  {
    id: "contra-file-fritas",
    slug: "contra-file-fritas",
    name: "Contra filé c/ fritas ou à cavalo",
    description: "Contra filé no ponto, escolha fritas ou à cavalo",
    category: "dishes",
    variants: [
      { label: "PF", priceCents: 3600 },
      { label: "Refeição", priceCents: 4900 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 8,
  },
  {
    id: "contra-file-cavalo",
    slug: "contra-file-cavalo",
    name: "Contra filé à cavalo c/ fritas",
    description: "Contra filé, ovo e fritas douradas",
    category: "dishes",
    variants: [
      { label: "PF", priceCents: 3800 },
      { label: "Refeição", priceCents: 5100 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 9,
  },
  {
    id: "suco-laranja",
    slug: "suco-laranja",
    name: "Suco de laranja",
    description: "Natural, gelado e espremido na hora",
    category: "drinks",
    variants: [
      { label: "Copo", priceCents: 1000 },
      { label: "Jarra 500ml", priceCents: 1400 },
      { label: "Jarra 1L", priceCents: 2400 },
    ],
    isAvailable: true,
    isVisible: true,
    sortOrder: 10,
  },
];

export function formatBRL(cents: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(cents / 100);
}
