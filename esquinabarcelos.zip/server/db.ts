import { asc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { DEFAULT_MENU_ITEMS, type MenuItem, type MenuItemInput } from "../shared/menu";
import { menuItems, users, type InsertUser } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function mapMenuRecord(record: typeof menuItems.$inferSelect): MenuItem {
  let variants = [] as MenuItem["variants"];
  try {
    const parsed = JSON.parse(record.variants);
    if (Array.isArray(parsed)) variants = parsed;
  } catch {
    variants = [];
  }

  return {
    id: String(record.id),
    slug: record.slug,
    name: record.name,
    description: record.description,
    category: record.category,
    variants,
    isAvailable: Boolean(record.isAvailable),
    isVisible: Boolean(record.isVisible),
    sortOrder: record.sortOrder,
  };
}

function inputToRecord(input: MenuItemInput, slug: string) {
  return {
    slug,
    name: input.name.trim(),
    description: input.description.trim(),
    category: input.category,
    variants: JSON.stringify(input.variants),
    isAvailable: input.isAvailable ? 1 : 0,
    isVisible: input.isVisible ? 1 : 0,
    sortOrder: input.sortOrder,
  } as const;
}

async function seedMenu(db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  const existing = await db.select({ id: menuItems.id }).from(menuItems).limit(1);
  if (existing.length > 0) return;

  await db.insert(menuItems).values(
    DEFAULT_MENU_ITEMS.map(item => inputToRecord(item, item.slug)),
  );
}

export async function listMenuItems(): Promise<MenuItem[]> {
  const db = await getDb();
  if (!db) return DEFAULT_MENU_ITEMS;
  try {
    await seedMenu(db);
    const rows = await db.select().from(menuItems).orderBy(asc(menuItems.sortOrder), asc(menuItems.id));
    return rows.map(mapMenuRecord);
  } catch (error) {
    console.warn("[Database] Falling back to the initial menu:", error);
    return DEFAULT_MENU_ITEMS;
  }
}

export async function createMenuItem(input: MenuItemInput) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const slug = input.slug?.trim() || `${input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}`;
  await db.insert(menuItems).values(inputToRecord(input, slug));
  return listMenuItems();
}

export async function updateMenuItem(id: string, input: MenuItemInput) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const numericId = Number(id);
  if (!Number.isInteger(numericId)) throw new Error("Invalid menu item id");
  const slug = input.slug?.trim() || `${input.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${numericId}`;
  await db.update(menuItems).set(inputToRecord(input, slug)).where(eq(menuItems.id, numericId));
  return listMenuItems();
}

export async function deleteMenuItem(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const numericId = Number(id);
  if (!Number.isInteger(numericId)) throw new Error("Invalid menu item id");
  await db.delete(menuItems).where(eq(menuItems.id, numericId));
  return listMenuItems();
}

export async function toggleMenuItem(id: string, field: "isAvailable" | "isVisible", value: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const numericId = Number(id);
  if (!Number.isInteger(numericId)) throw new Error("Invalid menu item id");
  await db.update(menuItems).set({ [field]: value ? 1 : 0 }).where(eq(menuItems.id, numericId));
  return listMenuItems();
}
