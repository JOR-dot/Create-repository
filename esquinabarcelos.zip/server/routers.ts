import { z } from "zod";
import { listMenuItems, createMenuItem, deleteMenuItem, toggleMenuItem, updateMenuItem } from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";

const variantSchema = z.object({
  label: z.string().trim().min(1).max(40),
  priceCents: z.number().int().min(0).max(999999),
});

const menuInputSchema = z.object({
  id: z.string().optional(),
  slug: z.string().trim().max(120).optional(),
  name: z.string().trim().min(2).max(180),
  description: z.string().trim().max(500).default(""),
  category: z.enum(["dishes", "drinks", "accompaniments"]),
  variants: z.array(variantSchema).min(1).max(8),
  isAvailable: z.boolean(),
  isVisible: z.boolean(),
  sortOrder: z.number().int().min(0).max(9999),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  menu: router({
    list: publicProcedure.query(() => listMenuItems()),
  }),
  admin: router({
    list: adminProcedure.query(() => listMenuItems()),
    create: adminProcedure.input(menuInputSchema).mutation(({ input }) => createMenuItem(input)),
    update: adminProcedure.input(menuInputSchema).mutation(({ input }) => {
      if (!input.id) throw new Error("Menu item id is required");
      return updateMenuItem(input.id, input);
    }),
    remove: adminProcedure.input(z.object({ id: z.string() })).mutation(({ input }) => deleteMenuItem(input.id)),
    toggle: adminProcedure.input(z.object({ id: z.string(), field: z.enum(["isAvailable", "isVisible"]), value: z.boolean() })).mutation(({ input }) => toggleMenuItem(input.id, input.field, input.value)),
  }),
});

export type AppRouter = typeof appRouter;
