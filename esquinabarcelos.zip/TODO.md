# Entregas — Esquina Barcelos

## Cardápio público e identidade visual

- [x] Aplicação web completa, responsiva e pronta para produção para o restaurante “Esquina Barcelos”, com interface mobile-first para navegação rápida por QR Code.
- [x] Identidade visual aplicada com vermelho artesanal `#C82333`, amarelo/dourado acolhedor, terracota e fundo off-white/creme `#FDFBF7`, incluindo botões de ação destacados.
- [x] Navegação organizada em abas “Pratos do Dia”, “Bebidas” e “Acompanhamentos”.
- [x] Dados iniciais dos 9 pratos de sábado e suas variantes de tamanho/preço carregados via seed idempotente.
- [x] Acompanhamentos opcionais Arroz, Feijão, Farofa e Salada exibidos com a observação de cobrança à parte quando aplicável.
- [x] Bebidas de suco de laranja exibidas com Copo R$ 10,00, Jarra 500ml R$ 14,00 e Jarra 1L R$ 24,00.

## Montagem do pedido e WhatsApp

- [x] Modal de item com opções de tamanho Mini, Prato Feito ou Refeição somente quando aplicáveis, exibindo o preço correspondente.
- [x] Seleção de acompanhamentos durante a montagem do prato.
- [x] Carrinho flutuante com lista dinâmica, inclusão, edição, remoção, quantidades, detalhes das escolhas e cálculo automático do total dos itens.
- [x] Campos de Nome do Cliente e escolha entre Entrega e Retirada; Endereço de Entrega é obrigatório quando a modalidade for entrega.
- [x] Link `https://wa.me/5521987725876?text=...` com mensagem codificada contendo cliente, modalidade, endereço quando aplicável, itens, tamanhos, acompanhamentos, quantidades, subtotal/total e observação sobre extras.

## Área administrativa

- [x] Rota restrita `/admin` com autenticação do proprietário via sessão oficial, estado de acesso negado para outras roles e opção de terminar sessão.
- [x] CRUD administrativo para adicionar, editar e remover pratos, bebidas e demais itens, incluindo nomes, descrições, categorias, tamanhos e preços.
- [x] Alteração de valores e controles para alternar visibilidade e disponibilidade dos pratos do dia.
- [x] Invalidação de queries para refletir mudanças administrativas imediatamente no cardápio público.

## Persistência e qualidade técnica

- [x] Cardápio, preços, disponibilidade e visibilidade persistidos no banco gerenciado via Drizzle, com seed inicial idempotente e fallback dos dados iniciais em falhas de leitura.
- [x] Arquitetura modular em `components`, `context`, `hooks`, `types`/`shared` e `data`/seed, com validações tRPC, mensagens de erro, tratamento de carregamento e código otimizado para ambiente web.
- [x] Manifesto de rotas, configuração de execução, `pnpm check`, `pnpm test` e `pnpm build` validados; Preview revisado em desktop e mobile.
